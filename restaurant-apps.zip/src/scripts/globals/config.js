const CONFIG = {
  BASE_URL: 'https://restaurant-api.dicoding.dev/',
  baseImgaeUrl: (size) => `https://restaurant-api.dicoding.dev/images/${size}`,
  DATABASE_NAME: `MakaNin`,
  DATABASE_VERSI: 1,
  OBJECT_STORE_NAME: 'restoran',
  DEFAULT_LANGUAGE: 'en-us',
};

export default CONFIG;
